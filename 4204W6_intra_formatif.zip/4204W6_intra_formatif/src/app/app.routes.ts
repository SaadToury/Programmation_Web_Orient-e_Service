import { Routes } from '@angular/router';
import { Component } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { ListComponent } from './list/list.component';
import { FavoritesComponent } from './favorites/favorites.component';
import { SingleComponent } from './single/single.component';
export const routes: Routes = [
    { path: '', component: ListComponent },
    { path: 'list', component: ListComponent },
    { path: 'favorites', component: FavoritesComponent },
    { path: 'single', component: SingleComponent },
    { path: "single/:name", component: SingleComponent }


];
