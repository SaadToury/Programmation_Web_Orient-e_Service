import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Pokemon } from '../models/pokemon';
import { PokeapiService } from '../services/pokeapi.service';
import { CommonModule } from '@angular/common';
import { FavoritesComponent } from '../favorites/favorites.component';
import { ListComponent } from '../list/list.component';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-single',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './single.component.html',
  styleUrl: './single.component.css'
})
export class SingleComponent {
  pokemon: Pokemon | undefined;

  constructor(private route: ActivatedRoute,
    private pokeapiService: PokeapiService) { }

  ngOnInit(): void {
    const name = this.route.snapshot.paramMap.get('name');
    if (name) {
      this.pokeapiService.getSinglePkmn(name).subscribe(data => {
        console.log(data);
        this.pokemon = data;
      });
    }
  }
  addToFavorites(pokemon: any) {
    let favorites = JSON.parse(localStorage.getItem('favorites') || '[]');

    if (!favorites.some((fav: any) => fav.id === pokemon.id)) {
      favorites.push(pokemon);
      localStorage.setItem('favorites', JSON.stringify(favorites));
    }
  }
}
