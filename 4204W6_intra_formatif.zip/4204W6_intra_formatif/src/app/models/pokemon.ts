export class Pokemon {
    constructor(public id: number, public name: string, public imgSrc: string) {
        this.id = id;
        this.name = name;
        this.imgSrc = imgSrc;
    }

}
export interface Sprites {
    front_default: string;
}
export interface Pokemon {
    id: number;
    name: string;
    sprites: Sprites;
}